#pragma once

#include "system_settings.h"

using namespace adf;

class FirKernel: public graph
{
private:
	// FIR coefficients
	std::vector<int16> m_taps = std::vector<int16>{-1, -3, 3, -1, -3,
		6, -1, -7, 9, -1, -12, 14, 1, -20, 19, 5, -31, 26, 12, -45, 32, 23, -63,
		37, 40, -86, 40, 64, -113, 39, 96, -145, 33, 139, -180, 17, 195, -218, -9,
		266, -258, -53, 357, -299, -118, 472, -339, -215, 620, -376, -360, 822,
		-409, -585, 1118, -437, -973, 1625, -458, -1801, 2810, -470, -5012, 10783,
		25067};

	//FIR Graph class
	xf::dsp::aie::fir::sr_sym::fir_sr_sym_graph<DATA_TYPE, COEFF_TYPE, FIR_LEN, SHIFT,
	ROUND_MODE, WINDOW_SIZE> firGraph;

public:
	port<input> in;
	port<output> out;

	// Constructor - with FIR graph class initialization
	FirKernel():firGraph(m_taps) {
		// Make connections
		// Size of window in Bytes.
		// Margin gets automatically added within the FIR graph class.
		// Margin equals to FIR length rounded up to nearest multiple of 32 Bytes.
		connect<>(in, firGraph.in);
		connect<>(firGraph.out, out);
	};
};
