#pragma once

#include <adf.h>
#include "fir_sr_sym_graph.hpp"

// Filter parameters
#define DATA_TYPE cint16
#define COEFF_TYPE int16

#define FIR_LEN 129
#define SHIFT 15
#define ROUND_MODE 0
#define WINDOW_SIZE 256

// Simulation parameters
#define NUM_ITER 4


