#include "fir_graph.h"


simulation::platform<1,1> platform("data/input.txt", "data/output.txt");
FirKernel filter ;

connect<> net0(platform.src[0], filter.in);
connect<> net1(filter.out, platform.sink[0]);

int main(void) {
filter.init() ;
filter.run(4) ;
filter.end() ;
return 0 ;
}
